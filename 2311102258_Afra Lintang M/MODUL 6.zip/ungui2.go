package main

import (
	"fmt"
)

func printBintang(n int) {
	if n == 0 {
		return
	}
	fmt.Print("*")
	printBintang(n - 1)
}

func printPola(n, current int) {
	if current > n {
		return
	}
	printBintang(current)
	fmt.Println()
	printPola(n, current+1)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai N: ")
	fmt.Scan(&n)

	fmt.Println("Pola bintang:")
	printPola(n, 1)
}
