package main

import (
	"fmt"
)

func printBilanganGanjil(n, current int) {
	if current > n {
		return
	}
	if current%2 != 0 { 
		fmt.Print(current, " ")
	}
	printBilanganGanjil(n, current+1)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai N: ")
	fmt.Scan(&n)

	fmt.Printf("Bilangan ganjil dari 1 hingga %d adalah: ", n)
	printBilanganGanjil(n, 1)
	fmt.Println()
}
