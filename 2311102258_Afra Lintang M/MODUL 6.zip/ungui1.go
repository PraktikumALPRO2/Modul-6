package main

import (
	"fmt"
)

func FIBONACCI(n int) int {
	if n <= 1 {
		return n
	}
	return FIBONACCI(n-1) + FIBONACCI(n-2)
}

func main() {
	var n int
	fmt.Print("Masukkan nilai n untuk batas deret FIBONACCI: ")
	fmt.Scan(&n)

	fmt.Print("n\t| ")
	for i := 0; i <= n; i++ {
		fmt.Printf("%d\t", i)
	}
	fmt.Println()

	fmt.Print("Sn\t| ")
	for i := 0; i <= n; i++ {
		fmt.Printf("%d\t", FIBONACCI(i))
	}
	fmt.Println()
}
