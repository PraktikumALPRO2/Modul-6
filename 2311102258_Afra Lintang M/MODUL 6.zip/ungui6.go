package main

import (
	"fmt"
)

func POWER(x, y int) int {
	if y == 0 {
		return 1
	}
	return x * POWER(x, y-1)
}

func main() {
	var x, y int
	fmt.Print("Masukkan bilangan x (basis): ")
	fmt.Scan(&x)
	fmt.Print("Masukkan bilangan y (pangkat): ")
	fmt.Scan(&y)

	result := POWER(x, y)
	fmt.Printf("Hasil %d pangkat %d adalah: %d\n", x, y, result)
}
