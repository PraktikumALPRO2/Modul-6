package main

import "fmt"


// Fungsi rekursif untuk menampilkan bilangan dari N ke 1 dan kembali ke N
func printSequence(n, current int) {
	// Cetak bilangan saat ini
	fmt.Printf("%d ", current)

	// Jika mencapai 1, mulai kembali naik ke N
	if current == 1 {
		return
	}

	// Panggil rekursi untuk menurun
	printSequence(n, current-1)
	
	// Cetak bilangan saat naik lagi dari 2 ke N
	if current > 1 {
		fmt.Printf("%d ", current)
	}
}

func main() {
	var n int
	fmt.Print("Masukkan bilangan positif: ")
	fmt.Scan(&n)
	fmt.Printf("Barisan dari %d ke 1 dan kembali ke %d: ", n, n)
	printSequence(n, n)
	fmt.Println()
}
