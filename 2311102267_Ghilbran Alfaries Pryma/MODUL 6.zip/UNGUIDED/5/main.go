package main

import "fmt"


// Fungsi rekursif untuk menampilkan bilangan ganjil dari 1 hingga N
func printOddSequence(n, current int) {
	// Jika current melebihi N, kita keluar dari rekursi
	if current > n {
		return
	}
	// Cetak bilangan ganjil saat ini
	fmt.Printf("%d ", current)
	// Panggil rekursi dengan menambah current sebesar 2 untuk mendapatkan bilangan ganjil berikutnya
	printOddSequence(n, current+2)
}

func main() {
	var n int
	fmt.Print("Masukkan bilangan positif: ")
	fmt.Scan(&n)
	fmt.Printf("Barisan bilangan ganjil dari 1 hingga %d: ", n)
	printOddSequence(n, 1)
	fmt.Println()
}
