package main

import "fmt"

func main() {
	var x, y int
	fmt.Print("Masukkan bilangan x: ")
	fmt.Scanln(&x)
	fmt.Print("Masukkan bilangan y: ")
	fmt.Scanln(&y)

	result := power(x, y)
	fmt.Printf("Hasil pangkat %d ^ %d adalah %d\n", x, y, result)
}

func power(x, y int) int {
	if y == 0 {
		return 1
	}
	return x * power(x, y-1)
}