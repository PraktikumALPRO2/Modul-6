package main

import "fmt"

// Fungsi rekursif untuk menampilkan satu baris bintang
func printStars(n int) {
	if n == 0 {
		return
	}
	fmt.Print("*")
	printStars(n - 1)
}

// Fungsi rekursif untuk menampilkan pola bintang
func printPattern(n, current int) {
	if current > n {
		return
	}
	printStars(current)
	fmt.Println()
	printPattern(n, current+1)
}

func main() {
	var n int
	fmt.Print("Masukkan angka: ")
	fmt.Scan(&n)

	printPattern(n, 1)
}
